package com.example.urlonlybrowser

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 10, 10, 6)
        }
        address = EditText(this).apply {
            hint = "أدخل رابط الموقع فقط"
            textSize = 15f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(14, 8, 14, 8)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val go = Button(this).apply { text = "فتح" }
        bar.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        bar.addView(go, LinearLayout.LayoutParams(-2, 48))
        root.addView(bar)

        status = TextView(this).apply {
            text = "اكتب رابطاً فقط، مثل youtube.com"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(14, 0, 14, 8)
        }
        root.addView(status)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    status.text = url ?: ""
                    address.setText(url ?: "")
                }
            }
            webChromeClient = WebChromeClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 8)
        }
        fun control(label: String, action: () -> Unit) {
            val b = Button(this).apply { text = label; setOnClickListener { action() } }
            controls.addView(b, LinearLayout.LayoutParams(0, 48, 1f))
        }
        control("رجوع") { if (web.canGoBack()) web.goBack() }
        control("تقدم") { if (web.canGoForward()) web.goForward() }
        control("تحديث") { web.reload() }
        root.addView(controls)
        setContentView(root)

        go.setOnClickListener { openAddress() }
        address.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { openAddress(); true } else false
        }
    }

    private fun openAddress() {
        var input = address.text.toString().trim()
        if (input.isEmpty()) {
            status.text = "أدخل رابطاً أولاً"
            return
        }
        if (input.contains(" ") || !input.contains(".")) {
            status.text = "مرفوض: أدخل رابط موقع، وليس كلمات للبحث"
            return
        }
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = "https://$input"
        }
        val hostPart = input.removePrefix("https://").removePrefix("http://").substringBefore("/")
        if (!hostPart.contains(".") || hostPart.startsWith(".") || hostPart.endsWith(".")) {
            status.text = "الرابط غير صالح"
            return
        }
        web.loadUrl(input)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
